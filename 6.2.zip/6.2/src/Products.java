import java.util.HashMap;

public class Products {

	public static void main(String[] args) {
		HashMap<String,String>  products=new HashMap<String , String>();
		products.put("P001","Soap");
		products.put("P002","Dates");
		products.put("P003","Chocos");
		for (String i : products.keySet()) {
			  System.out.println("key: " + i + " value: " + products.get(i));
			}
		
		products.containsKey("P001");
		products.containsKey("Dates");
		
		products.remove("P002");
		System.out.println("After removing P002");
		for (String i : products.keySet()) {
			  System.out.println("key: " + i + " value: " + products.get(i));
			}
		
		
		
	}

}
