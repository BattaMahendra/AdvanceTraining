package com.Medicines;

public interface MedicineInfo {
	public abstract void displayLabel() ;

}
