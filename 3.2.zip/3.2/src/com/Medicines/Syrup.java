package com.Medicines;

public class Syrup implements MedicineInfo {

	@Override
	public void displayLabel() {
		
		System.out.println(" to be taken as prescribed by doctor");
	}
}