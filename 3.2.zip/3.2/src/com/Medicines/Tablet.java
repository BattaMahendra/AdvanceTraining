package com.Medicines;

public class Tablet implements MedicineInfo {

	@Override
	public void displayLabel() {
		System.out.println(" store in a cool dry place");
		
	}
	

}
