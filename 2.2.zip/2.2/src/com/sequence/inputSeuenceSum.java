package com.sequence;

import java.util.Scanner;

public class inputSeuenceSum {
	public static void sequenceSum(int i1,int i2) {
		int sum=0;
		int i=13;
		System.out.print(i1+" ,"+i2+" ,");
		while(i!=0) {
			sum=i1+i2;
			System.out.print(sum+" , ");
			i1=i2;
			i2=sum;
			i--;
			
		}
		
	}

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter two numbers you wish");
		int i1=sc.nextInt();
		int i2=sc.nextInt();
		sc.close();
		sequenceSum(i1, i2);

	}

}
