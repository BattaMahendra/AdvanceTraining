import java.util.Scanner;

public class StringPalindrome {
	
	public static void Palindrome(String input) {
		String s="";
		for(int i=input.length()-1;i>=0;i--) {
			s+=input.charAt(i);
		}
		if(s.equals(input)) {
			System.out.println("it is a palindrome");
		}else System.out.println("it is not a palindrome");
	}

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter a word you wish");
		String i=sc.nextLine().toUpperCase();
		sc.close();
		System.out.println("Lendth of the given String "+i.length());
		Palindrome(i);
		
	}

}
