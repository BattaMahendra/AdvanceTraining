package com.mycompany.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.dbutil.DBUtil;
import com.mycompany.domain.product;

public class ProductmanagementDAO {
	
	Connection connect;
	Statement stmt;
	ResultSet rs;
	
//	to retrive all products
	
	public List<product> getAllProducts() throws ClassNotFoundException, SQLException{
		
		List<product> productsList=new ArrayList<product>();
		connect=DBUtil.getConnection();
		stmt=connect.createStatement();
		rs=stmt.executeQuery("SELECT * FROM Product");
		while(rs.next()) {
			product myProduct=new  product(rs.getString(1),rs.getString(2),rs.getInt(3));
			productsList.add(myProduct);
			
		}
		DBUtil.closeConnection(connect);
		return productsList;	
			
		}
	
	 public int addProduct(product product1)
	    {
	        //status displays 1 if successfully inserted data or error; successful or not
	        int status = 0;
	        try
	        {
	            connect = DBUtil.getConnection();
	            PreparedStatement ps = connect.prepareStatement("INSERT INTO product VALUES(?,?,?)");
	            //set parameters of query here but using the values for the product object
	            ps.setString(1, product1.product_id());
	            ps.setString(2, product1.product_name());
	            ps.setInt(3, product1.product_price());
	            status = ps.executeUpdate();  //if successful status should return 1
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }
	        return status;
	    }
	 
	  //updates a product already in the table
	    public int updateProduct(product product)
	    {
	        int status = 0;
	        try
	        {
	            Connection conn = DBUtil.getConnection();
	            PreparedStatement ps = conn.prepareStatement("UPDATE product SET prod_name=?, prod_price=? WHERE prod_id=?");
	            //set parameters of query here but using the values for the product object
	            ps.setString(1, product.product_name());
	            ps.setInt(2, product.product_price());
	            ps.setString(3, product.product_id());
	            status = ps.executeUpdate();  //if successful status should return 1
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }
	        return status;
	    }

	    //deltes product already in the table
	    public int deleteProduct(String productId)
	    {
	        int status = 0;
	        try
	        {
	            Connection conn = DBUtil.getConnection();
	            PreparedStatement ps = conn.prepareStatement("DELETE FROM product where prod_id = ?");
	            //set parameters of query here but using the values for the product object
	            ps.setString(1, productId);
	            status = ps.executeUpdate();  //if successful status should return 1

	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }
	        return status;
	    }
	    
	    public product getProductByid(String productId)
	    {
	        product product = null;
	        try
	        {
	            Connection conn = DBUtil.getConnection();
	            PreparedStatement ps = conn.prepareStatement("SELECT * FROM product WHERE product_id = ?");
	            ps.setString(1, productId);
	            ResultSet rs = ps.executeQuery();
	            //iterate through result
	            while(rs.next())
	            {
	                product = new product(rs.getString("product_id"), rs.getString("product_name"), rs.getInt("product_price"));
	            }
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }
	        return product;
	    }

	}


