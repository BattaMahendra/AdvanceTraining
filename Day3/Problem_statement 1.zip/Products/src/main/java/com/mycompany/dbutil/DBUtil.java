package com.mycompany.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	
//	getting a connection
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		Connection connect;
		Class.forName("com.mysql.cj.jdbc.Driver");
		connect=DriverManager.getConnection("jdbc:mysql://localhost:3306/advancetraining", "root", "bmcm1999@M");
		return connect;
	}

	// closing a connection
	
	public static void closeConnection(Connection connect) throws SQLException {
		connect.close();
	}
}
