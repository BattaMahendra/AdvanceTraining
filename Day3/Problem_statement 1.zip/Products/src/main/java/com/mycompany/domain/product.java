package com.mycompany.domain;


public record product(String product_id,String product_name,int product_price){

	public String product_id() {
		return product_id;
	}

	public String product_name() {
		return product_name;
	}

	public int product_price() {
		return product_price;
	}}
