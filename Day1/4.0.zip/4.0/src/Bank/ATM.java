package Bank;

public class ATM {

	public static void main(String[] args) {
		BankAccount b=new BankAccount(123456, "Mahendra", "Current", 6000);
		System.out.println(" your current balance is "+b.getBalance());
		b.withdraw(5000);
		b.deposit(100000);

	}

}
