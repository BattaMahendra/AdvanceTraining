package Bank;

public class BankAccount {
	
	int accountNumber;
    String CustName;
    String accountType;
    double balance;

	
	    public BankAccount(int accountNumber, String custName, String accountType, double balance) {
		super();
		this.accountNumber = accountNumber;
		CustName = custName;
		this.accountType = accountType;
		this.balance = balance;
	}
	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCustName() {
		return CustName;
	}

	public void setCustName(String custName) {
		CustName = custName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void deposit(double amount) {
		
		if (amount<0) {
			try {
				 throw new NumberFormatException();
			}
			catch(NumberFormatException exe){
				
				System.out.println("Negative Amount");
			}
		}else {
			balance=balance+amount;
			System.out.println("After deposit current balance  is "+this.getBalance());
		}
		
	}
	
	public void withdraw(double amount) {
		if(accountType.equals("Savings")) {
			if(this.getBalance()<=1000) {
				try {
					 throw new NumberFormatException();
				}
				catch(NumberFormatException exe){
					
					System.out.println("Insufficient Funds");
				}
			}else {
				balance=balance-amount;
				System.out.println("After withdrawel of "+amount+" current balance after withdrawel is "+this.getBalance());
			}
			}else {
				
				if(this.getBalance()<=5000) {
					try {
						 throw new NumberFormatException();
					}
					catch(NumberFormatException exe){
						
						System.out.println("Insufficient Funds");
					}
				}else {
					balance=balance-amount;
					System.out.println("After withdrawel of "+amount+" current balance after withdrawel is "+this.getBalance());
			
		}
	}

}
}
