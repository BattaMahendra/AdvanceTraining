package com.strings;

import java.util.Arrays;

public class StringSplit {

	public static void main(String[] args) {
		String input= "23  +      45   -(   343   /   12  )";
		String[] arr=input.split("(?<=\\d)(?=\\D)|(?<=\\D)(?=\\d)|(?=\\D)(?=\\D)");
		for(int i=0; i<arr.length;i++) {
			if((arr[i].equals(" "))!=true) {
		System.out.println(arr[i]);
			}
	}

}
}
