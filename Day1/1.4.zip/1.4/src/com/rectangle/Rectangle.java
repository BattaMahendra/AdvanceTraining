package com.rectangle;

public class Rectangle {

	double Length =1;
	double Width=1;
	
	public Rectangle(double length, double width) {
		super();
		if(length>0.0&&length<20.0) {
			Length = length;
			}else System.out.println("lendth is not in limits");
		if(width>0.0&&width<20.0) {
			Width = width;
			}else {
				System.out.println("width is not in limits");
				System.out.println("These are default parameters");
			}
	}
	
	public double getLength() {
		return Length;
	}
	public void setLength(double length) {
		if(length>0.0&&length<20.0) {
		Length = length;
		}else System.out.println("lendth is not in limits");
	}
	public double getWidth() {
		return Width;
	}
	public void setWidth(double width) {
		if(width>0.0&&width<20.0) {
		Width = width;
		}else System.out.println("width is not in limits");
	}
	
	public void infoOfRectangle() {
		double area =Length*Width;
		System.out.println("Length of Rectangle is "+ Length+" units");
		System.out.println("Width of Rectangle is "+ Width+" units");
		System.out.println("Perimeter of Rectangle is "+ 2*(Length+Width)+" units");
		System.out.println("area of the Rectangle is "+ area+" sq.units");
	}
	

	
}
