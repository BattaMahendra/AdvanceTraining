import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileCopy {

	public static void main(String[] args) throws IOException {
		
		FileCopy myObj=new FileCopy();
		
		File file =new File("C:\\Users\\srava\\Desktop\\SourceFile.txt");
		 System.out.println("created source file");
		 FileWriter myWriter=new FileWriter(file);
		 myWriter.write("Hello this is Mahendras");
		 myWriter.close();
	      Scanner myReader = new Scanner(file);
	      String data="";
	      while (myReader.hasNextLine()) {
	         data = myReader.nextLine();
	        System.out.println(data);
	      }
          myReader.close();
          System.out.println("do yo want to copy if yes then give 1");
          Scanner sc=new Scanner(System.in);
          int i=sc.nextInt();
          if(i==1) {
	      File file2 =new File("C:\\Users\\srava\\Desktop\\DestinationFile.txt");
	      FileWriter myWriter2=new FileWriter(file2);
	      myWriter2.write(data);
	      myWriter2.close();
	      Scanner myReader2 = new Scanner(file);
	      while (myReader2.hasNextLine()) {
		         String data1 = myReader2.nextLine();
		        System.out.println(data1);
		      }
	      System.out.println("successfully copied");
	      
	      
	      
	}

}
}
