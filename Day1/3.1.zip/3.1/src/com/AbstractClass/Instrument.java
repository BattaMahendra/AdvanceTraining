package com.AbstractClass;

public abstract class Instrument {
	
public abstract void play();
}
