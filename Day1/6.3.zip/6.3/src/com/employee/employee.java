package com.employee;

public class employee {
	public employee(int empNumber, String empName, String empAddress) {
		super();
		this.empNumber = empNumber;
		this.empName = empName;
		this.empAddress = empAddress;
	}
	int empNumber;
	String empName;
	String empAddress;
	public int getEmpNumber() {
		return empNumber;
	}
	public void setEmpNumber(int empNumber) {
		this.empNumber = empNumber;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

}
