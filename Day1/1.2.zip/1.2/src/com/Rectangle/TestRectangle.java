package com.Rectangle;

import java.util.Scanner;

public class TestRectangle {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the length of Rectangle");
		double L=sc.nextDouble();
		System.out.println("Enter the breadth of Rectangle");
		double B=sc.nextDouble();
		sc.close();
		Rectangle r1=new Rectangle(L,B);
		r1.infoOfRectangle();
		
	}

}
