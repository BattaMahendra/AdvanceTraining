import java.util.ArrayList;
import java.util.List;

public class ArrayLists {

	public static void main(String[] args) {
		List<String> sNames=new ArrayList<String>();
		sNames.add("Lavanya");
		sNames.add("Sai");
		sNames.add("Mahendra");
		sNames.add("Vivek");
		
		;
		System.out.println(sNames.contains("Mahendra"));
	}

}
